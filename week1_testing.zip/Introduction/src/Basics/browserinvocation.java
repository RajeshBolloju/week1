package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class browserinvocation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//firefox 48+ - - selenium 3.0 ->  supplement step needed as show below
		
		System.setProperty("webdriver.gecko.driver","/Users/RajeshKhanna/Downloads/geckodriver"); //supplementstep
		WebDriver driver=new FirefoxDriver();
		driver.get("http://cbtnuggets.com"); //get to hit the url
		System.out.println(driver.getTitle()); // to know the title
		System.out.println(driver.getPageSource()); 
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}

}
