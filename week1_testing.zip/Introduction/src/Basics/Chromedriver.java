package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Chromedriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","/Users/RajeshKhanna/Downloads/chromedriver"); //must write in the first line
		WebDriver driver=new ChromeDriver();
		driver.get("http://google.com");
		
		/*internet explorer driver
		System.setProperty(key, value)
		WebDriver driver=new SafariDriver();
		driver.get("http://google.com");*/
	}

}
