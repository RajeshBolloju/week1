
public class printstringinreverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//* for just reversing string
		
		String s="Rajesh";//*
		String t=""; //to know for polindrome number
		//need output as "hsejar" i.e., reversing the string
		
		for(int i=s.length()-1;i>=0;i--)	//*
		{
			//System.out.println(s.charAt(i)); //prints the string in reverse order*
			//and to know whether its a palindrome or not follow below step 
			t= t+ s.charAt(i); //till here also gives the reverse order of the string
		}
		System.out.println(t);
		
		if(s==t)
		{
			System.out.println("yes it is a palindrome");
		}
		
	}

}
