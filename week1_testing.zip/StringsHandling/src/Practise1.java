
public class Practise1 {

	public static void main(String[] args) { //public static void -->
		// TODO Auto-generated method stub

		String str="Payment $100 paid";
		//class  object
		System.out.println(str.charAt(8));
									//8 - -> is index
									//gives the character which is present in the 8th index
									//$ is in 8th position for single payment
									//$ is in 9th position for multiple payments
		String str1="Payments $100 paid";
		System.out.println(str.indexOf("$"));
		//prints the index wherever the index is present
		System.out.println(str.substring(2));
		//prints from the index given
		
	}

}
