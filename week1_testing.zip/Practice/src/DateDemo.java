import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//print current date and time
		Date d=new Date();
		
		SimpleDateFormat df=new SimpleDateFormat("MM/dd/yyyy"); //format 1
		System.out.println(df.format(d));

		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy hh:mm:ss"); //format 2
		System.out.println(sdf.format(d));

		//System.out.println(d.toString()); //for general output of date and time
	}

}
