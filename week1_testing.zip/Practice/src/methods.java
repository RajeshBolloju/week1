
public class methods {

	public String ValidateHeader() // 
	{
		System.out.println("Header links validated");
		return "Pass";
	}
	}


