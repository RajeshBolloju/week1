
public class Parent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("I navigated to home page");
		
		methods m=new methods();
		System.out.println(m.ValidateHeader());
		
		
		//class object_name= new class();
		//object_name.methodname();
		
	}

}
