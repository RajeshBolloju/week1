
public class sumofnumbers_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//sum of number in an array-- array is an collection of objects -->*
	
		//	int sum=0; //*
		int c[ ]={2,7,4,3,3};
		for(int i=0;i<c.length; i++)
		{
			//sum=sum+c[i];  //*
			if(c[i]==3) //to find index of a given number
			{
				System.out.println(i);
				
				break; //comes out of all loops once we get the output
						//use it to optimize the code
			}
		}
		//System.out.println(sum); //*
	
	}

}
