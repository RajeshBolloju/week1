
public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Array - -> A container which stores multiples values of same data type
		/*int a;
		a=4;*/
		
	/*	int a[]=new int[5]; //Declares an array and allocates memory for 5 values
		a[0]=2; a[1]=3;a[2]=4;a[3]=9;a[4]=10; //initialized values into that array*/
		
		int b[]={3,6,5,9,10};
		
		for(int i=0;i<b.length;i++)
		{
		System.out.println(b[i]);	
		}
		
	}

}
