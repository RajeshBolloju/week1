
public class Minimumnumber {

	public static void main(String[] args) {
		//to find the maximum number from the minimum column*
		
		// TODO Auto-generated method stub
		//  9 4 6
		//  5 12 8
		//  15 7 5
		int b[][]={{2,4,6},{5,12,8},{15,7,5}};
		int min=b[0][0]; //assuming minimum number in the array
		int mincolumn = 0; //to identify the minimum column*
		for(int i=0;i<3;i++) // "3" for 3 rows going into loop for 3 times because given i<2
			
		{
			for(int j=0;j<3;j++)	// "3" for 3 columns, going into the loop for 3 times because give j<3
			{
				if (b[i][j]<min)	// invert operator for maximum number ">"
				{
				min=b[i][j];
				mincolumn=j;	 //to identify the minimum column*

				}
			}
		}  
		System.out.println("minimum number from the array "+min); //to print the minimum/maximum number
		System.out.println("minimum column number "+ mincolumn);

		
		//		*----
		//   		|
		
		int max = b[0][mincolumn];
		int k = 0;
		while(k<3)
		{
		if (b[k][mincolumn]>max)
		{
			max=b[k][mincolumn];
		
		}
		k++;
		}
		
		System.out.println("maximum number from the minimum column "+ max);

	}	
	}


