
public class MultidimensionalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			//  2 4 6
			//  5 7 8
			//  9 7 0
		
		  //a[row][column]
		
		//int a[][]= new int [3][3];
		
		int b[][]={{2,4,6},{5,7,8}}; //{9,7,0}};
				//  0throw 1strow 		 2nd row
		
		//System.out.println(b[1][1]); //for printing the desired number of the array
		
		for(int i=0;i<2;i++) // "2" for 2 rows going into loop for 2 times because given i<2
		
		{
			for(int j=0;j<3;j++)// "3" for 3 columns, going into the loop for 3 times because give j<3
			{
			System.out.println(b[i][j]);
			}
		}
		
	}

}
