package InterfaceConcept;

public interface DomainClient {

	public void Investment();
		
	}

