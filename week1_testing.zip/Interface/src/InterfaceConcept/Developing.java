package InterfaceConcept;

public class Developing implements BankingClient, DomainClient{ //can call more than one interface in one class
	
	//now this class (Developing) is responsible for ALL the methods of Banking Client Interface
	//

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Developing d=new Developing(); //d is responsible for calling methods of developing class
//object.method

BankingClient dr=new Developing(); //runtime polymorphism
									// dr calls only methods only from the BankingClient
DomainClient ds=new Developing(); //ds calls methods only from DomainClient

d.paycreditcard();
d.transferbalance();
d.login();

//if you want to call any method from any interfaces or from this class use object "d." **

dr.checkingbalance(); //it cannot call methods from Developing class like "dr.login()"
						// method checkingbalance is from BankingClient Interface
ds.Investment();	//method Investment is form DomainClient Interface
	}

	@Override
	public void paycreditcard() {
		// TODO Auto-generated method stub
		System.out.println("Pay Credit Card Implemented");
	}

	@Override
	public void transferbalance() {
		// TODO Auto-generated method stub
		System.out.println("Transfer Balance Implemented");

	}

	@Override
	public void checkingbalance() {
		// TODO Auto-generated method stub
		System.out.println("Checking Balance Updated");
	}

	public void login() 	{	// we can add methods other than that are in the Interface (BankingClient) that we called in 
								//beginning
	
		System.out.println("Login");
	}

	@Override
	public void Investment() {
		// TODO Auto-generated method stub
		System.out.println("Investing");
	}

}
