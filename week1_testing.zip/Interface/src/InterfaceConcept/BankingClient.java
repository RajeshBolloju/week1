package InterfaceConcept;

public interface BankingClient {
	public void paycreditcard();
	public void transferbalance();
	public void checkingbalance();
	

}
