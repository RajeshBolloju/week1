package Inheritence;

public class Parent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	}
public void city() //created method
{
	System.out.println("Hyderabad");
}
public void country() //created method
{
	System.out.println("India");
		
	}

}
