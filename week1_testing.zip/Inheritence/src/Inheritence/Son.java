package Inheritence;

public class Son extends Parent { 			//calling another method --> Parent
											//mention the class from which you have to inherite the properties

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Son s=new Son(); //created an object for Son
	s.city();		// it automatically shows the objects from the Parent which we called in the beginning
	s.country();
	
	
	}
}
